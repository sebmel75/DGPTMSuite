<?php
/**
 * Plugin Name: DGPTM - Daten bearbeiten
 * Plugin URI:  https://dgptm.de
 * Description: Member data editing form with Zoho CRM synchronization
 * Version:     1.0.0
 * Author:      Sebastian Melzer
 * Author URI:  https://dgptm.de
 * License:     GPL2
 */

if (!defined('ABSPATH')) {
    exit;
}

// Prevent class redeclaration
if (!class_exists('DGPTM_Daten_Bearbeiten')) {

    class DGPTM_Daten_Bearbeiten {

        private static $instance = null;
        private $plugin_path;
        private $plugin_url;
        private $version = '1.0.0';

        /**
         * Get singleton instance
         */
        public static function get_instance() {
            if (null === self::$instance) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Private constructor
         */
        private function __construct() {
            $this->plugin_path = plugin_dir_path(__FILE__);
            $this->plugin_url = plugin_dir_url(__FILE__);

            $this->init_hooks();
        }

        /**
         * Initialize WordPress hooks
         */
        private function init_hooks() {
            // Enqueue assets
            add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);

            // AJAX handlers
            add_action('wp_ajax_dgptm_load_member_data', [$this, 'ajax_load_member_data']);
            add_action('wp_ajax_dgptm_update_member_data', [$this, 'ajax_update_member_data']);
            add_action('wp_ajax_dgptm_load_accounts', [$this, 'ajax_load_accounts']);
            add_action('wp_ajax_dgptm_load_clinics', [$this, 'ajax_load_clinics']);

            // Shortcode
            add_shortcode('dgptm-daten-bearbeiten', [$this, 'render_edit_form']);
        }

        /**
         * Enqueue frontend assets
         */
        public function enqueue_frontend_assets() {
            // Only enqueue on pages with shortcode
            global $post;
            if (!is_a($post, 'WP_Post') || !has_shortcode($post->post_content, 'dgptm-daten-bearbeiten')) {
                return;
            }

            wp_enqueue_style(
                'dgptm-daten-bearbeiten',
                $this->plugin_url . 'assets/css/style.css',
                [],
                $this->version
            );

            wp_enqueue_script(
                'dgptm-daten-bearbeiten',
                $this->plugin_url . 'assets/js/script.js',
                ['jquery'],
                $this->version,
                true
            );

            wp_localize_script('dgptm-daten-bearbeiten', 'dgptmDatenBearbeiten', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('dgptm_daten_bearbeiten_nonce'),
                'redirectUrl' => 'https://perfusiologie.de/mitgliedschaft/interner-bereich/',
                'strings' => [
                    'loading' => 'Daten werden geladen...',
                    'saving' => 'Daten werden gespeichert...',
                    'success' => 'Daten erfolgreich gespeichert!',
                    'error' => 'Es ist ein Fehler aufgetreten. Bitte versuchen Sie es erneut.',
                ],
            ]);
        }

        /**
         * Render edit form shortcode
         */
        public function render_edit_form($atts) {
            if (!is_user_logged_in()) {
                return '<p>Sie müssen angemeldet sein, um Ihre Daten zu bearbeiten.</p>';
            }

            ob_start();
            include $this->plugin_path . 'templates/edit-form.php';
            return ob_get_clean();
        }

        /**
         * AJAX: Load member data from Zoho CRM
         */
        public function ajax_load_member_data() {
            $this->log('AJAX: Load member data called');

            check_ajax_referer('dgptm_daten_bearbeiten_nonce', 'nonce');

            if (!is_user_logged_in()) {
                $this->log('ERROR: User not logged in');
                wp_send_json_error(['message' => 'Nicht angemeldet']);
            }

            $user_id = get_current_user_id();
            $this->log('User ID: ' . $user_id);

            $zoho_id = get_user_meta($user_id, 'zoho_id', true);
            $this->log('Zoho ID from user meta: ' . ($zoho_id ? $zoho_id : 'EMPTY'));

            if (empty($zoho_id)) {
                $this->log('ERROR: No Zoho ID found for user ' . $user_id);
                wp_send_json_error(['message' => 'Keine Zoho ID gefunden. Bitte kontaktieren Sie die Geschäftsstelle.']);
            }

            // Get OAuth token
            $token = $this->get_oauth_token();
            if (!$token) {
                $this->log('ERROR: No OAuth token available');
                wp_send_json_error(['message' => 'OAuth-Token nicht verfügbar. Bitte aktivieren Sie das Mitgliedsantrag- oder CRM-Abruf-Modul.']);
            }

            $this->log('OAuth token obtained successfully');

            // Fetch contact data from Zoho CRM
            $contact_data = $this->fetch_contact_from_crm($zoho_id, $token);

            if (!$contact_data) {
                $this->log('ERROR: Contact not found in CRM for Zoho ID: ' . $zoho_id);
                wp_send_json_error(['message' => 'Kontakt nicht gefunden in Zoho CRM (ID: ' . $zoho_id . ')']);
            }

            $this->log('Contact data fetched successfully');

            // Map CRM data to form fields
            $form_data = $this->map_crm_to_form_data($contact_data);

            $this->log('Data mapped successfully, sending response');
            wp_send_json_success(['data' => $form_data]);
        }

        /**
         * AJAX: Update member data in Zoho CRM
         */
        public function ajax_update_member_data() {
            check_ajax_referer('dgptm_daten_bearbeiten_nonce', 'nonce');

            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => 'Nicht angemeldet']);
            }

            $user_id = get_current_user_id();
            $zoho_id = get_user_meta($user_id, 'zoho_id', true);

            if (empty($zoho_id)) {
                wp_send_json_error(['message' => 'Keine Zoho ID gefunden']);
            }

            // Get OAuth token
            $token = $this->get_oauth_token();
            if (!$token) {
                wp_send_json_error(['message' => 'OAuth-Token nicht verfügbar']);
            }

            // Log raw POST data
            $this->log('Raw POST data: ' . wp_json_encode($_POST));

            // Sanitize form data
            $form_data = $this->sanitize_form_data($_POST);

            $this->log('Sanitized form data: ' . wp_json_encode($form_data));

            // Update user email in WordPress if changed
            $new_email = sanitize_email($form_data['mail1']);
            $user = wp_get_current_user();

            if ($new_email !== $user->user_email) {
                wp_update_user([
                    'ID' => $user_id,
                    'user_email' => $new_email,
                ]);

                // Also update in user meta
                update_user_meta($user_id, 'billing_email', $new_email);
            }

            // Map form data to CRM fields
            $crm_data = $this->map_form_to_crm_data($form_data);

            $this->log('CRM data to send: ' . wp_json_encode($crm_data));

            // Update contact in Zoho CRM
            $success = $this->update_contact_in_crm($zoho_id, $crm_data, $token);

            if ($success) {
                wp_send_json_success(['message' => 'Daten erfolgreich aktualisiert']);
            } else {
                wp_send_json_error(['message' => 'Fehler beim Aktualisieren der Daten']);
            }
        }

        /**
         * Get OAuth token from mitgliedsantrag or crm-abruf module
         */
        private function get_oauth_token() {
            $this->log('Attempting to get OAuth token...');

            // Try to get token from mitgliedsantrag module (with automatic refresh)
            if (class_exists('DGPTM_Mitgliedsantrag')) {
                $this->log('DGPTM_Mitgliedsantrag class exists');
                $mitgliedsantrag = DGPTM_Mitgliedsantrag::get_instance();

                if (method_exists($mitgliedsantrag, 'get_access_token')) {
                    $this->log('get_access_token method exists, calling it...');
                    $token = $mitgliedsantrag->get_access_token();

                    if ($token) {
                        $this->log('Token obtained from mitgliedsantrag module (automatically refreshed if needed)');
                        return $token;
                    } else {
                        $this->log('mitgliedsantrag returned empty token');
                    }
                } else {
                    $this->log('get_access_token method does not exist in mitgliedsantrag');
                }
            } else {
                $this->log('DGPTM_Mitgliedsantrag class not found');
            }

            // Try crm-abruf module
            $this->log('Checking crm-abruf module...');
            if (class_exists('DGPTM_Zoho_CRM_Hardened')) {
                $this->log('DGPTM_Zoho_CRM_Hardened class exists');
                $crm_abruf = DGPTM_Zoho_CRM_Hardened::get_instance();
                if (method_exists($crm_abruf, 'get_access_token')) {
                    $this->log('get_access_token method exists, calling it...');
                    $token = $crm_abruf->get_access_token();
                    if ($token) {
                        $this->log('Token obtained from crm-abruf module');
                        return $token;
                    } else {
                        $this->log('crm-abruf returned empty token');
                    }
                } else {
                    $this->log('get_access_token method does not exist');
                }
            } else {
                $this->log('DGPTM_Zoho_CRM_Hardened class not found');
            }

            $this->log('ERROR: No OAuth token available from any source');
            return false;
        }

        /**
         * Fetch contact from Zoho CRM
         */
        private function fetch_contact_from_crm($zoho_id, $token) {
            $response = wp_remote_get(
                'https://www.zohoapis.eu/crm/v2/Contacts/' . $zoho_id,
                [
                    'headers' => [
                        'Authorization' => 'Zoho-oauthtoken ' . $token,
                    ],
                    'timeout' => 30
                ]
            );

            if (is_wp_error($response)) {
                $this->log('ERROR: Failed to fetch contact: ' . $response->get_error_message());
                return false;
            }

            $http_code = wp_remote_retrieve_response_code($response);
            $body = json_decode(wp_remote_retrieve_body($response), true);

            if ($http_code === 200 && isset($body['data'][0])) {
                return $body['data'][0];
            }

            return false;
        }

        /**
         * Update contact in Zoho CRM
         */
        private function update_contact_in_crm($zoho_id, $crm_data, $token) {
            $response = wp_remote_request(
                'https://www.zohoapis.eu/crm/v2/Contacts/' . $zoho_id,
                [
                    'method' => 'PUT',
                    'headers' => [
                        'Authorization' => 'Zoho-oauthtoken ' . $token,
                        'Content-Type' => 'application/json'
                    ],
                    'body' => wp_json_encode(['data' => [$crm_data]]),
                    'timeout' => 30
                ]
            );

            if (is_wp_error($response)) {
                $this->log('ERROR: Failed to update contact: ' . $response->get_error_message());
                return false;
            }

            $http_code = wp_remote_retrieve_response_code($response);
            $body = json_decode(wp_remote_retrieve_body($response), true);

            $this->log('Update response HTTP Code: ' . $http_code);
            $this->log('Update response: ' . wp_json_encode($body));

            return ($http_code >= 200 && $http_code < 300);
        }

        /**
         * Map CRM data to form fields
         */
        private function map_crm_to_form_data($crm_data) {
            return [
                // Read-only fields
                'vorname' => $crm_data['First_Name'] ?? '',
                'nachname' => $crm_data['Last_Name'] ?? '',
                'geburtsdatum' => $crm_data['Date_of_Birth'] ?? '',

                // Editable fields
                'ansprache' => $crm_data['greeting'] ?? 'Liebe(r)',
                'akad_titel' => $crm_data['Academic_Title'] ?? '',
                'titel_nach_name' => $crm_data['Title_After_The_Name'] ?? '',

                // Email addresses
                'mail1' => $crm_data['Email'] ?? '',
                'mail2' => $crm_data['Secondary_Email'] ?? '',
                'mail3' => $crm_data['Third_Email'] ?? '',

                // Address (using Mailing_ prefix)
                'strasse' => $crm_data['Mailing_Street'] ?? '',
                'adresszusatz' => $crm_data['Mailing_Street_Additional'] ?? '',
                'plz' => $crm_data['Mailing_Zip'] ?? '',
                'ort' => $crm_data['Mailing_City'] ?? '',
                'land' => $crm_data['Mailing_Country'] ?? 'Deutschland',

                // Phone numbers
                'telefon' => $crm_data['Phone'] ?? '',
                'mobil' => $crm_data['Mobile'] ?? '',
                'diensttelefon' => $crm_data['Work_Phone'] ?? '',

                // Journal preferences
                'journal_post' => ($crm_data['journal_post'] ?? false) ? 'true' : 'false',
                'journal_mail' => ($crm_data['journal_mail'] ?? false) ? 'true' : 'false',

                // Employer (can be lookup object or string)
                'employer' => $this->extract_employer_name($crm_data['employer'] ?? ''),
                'employer_id' => $this->extract_employer_id($crm_data['employer'] ?? ''),
                'employer_free' => $crm_data['Employer_free'] ?? '',
                'temporary_work' => $crm_data['temporary_work'] ?? '',

                // Status (read-only)
                'status' => $crm_data['Contact_Status'] ?? '',
            ];
        }

        /**
         * Map form data to CRM fields
         */
        private function map_form_to_crm_data($form_data) {
            // Helper function for boolean parsing
            $parse_bool = function($value) {
                return ($value === true || $value === 'true' || $value === '1' || $value === 1);
            };

            $crm_data = [
                'greeting' => $form_data['ansprache'] ?? '',
                'Academic_Title' => $form_data['akad_titel'] ?? '',
                'Title_After_The_Name' => $form_data['titel_nach_name'] ?? '',

                'Email' => $form_data['mail1'] ?? '',
                'Secondary_Email' => $form_data['mail2'] ?? '',
                'Third_Email' => $form_data['mail3'] ?? '',

                'Mailing_Street' => $form_data['strasse'] ?? '',
                'Mailing_Street_Additional' => $form_data['adresszusatz'] ?? '',
                'Mailing_Zip' => $form_data['plz'] ?? '',
                'Mailing_City' => $form_data['ort'] ?? '',
                'Mailing_Country' => $form_data['land'] ?? 'Deutschland',

                'Phone' => $form_data['telefon'] ?? '',
                'Mobile' => $form_data['mobil'] ?? '',
                'Work_Phone' => $form_data['diensttelefon'] ?? '',

                'journal_post' => $parse_bool($form_data['journal_post'] ?? false),
                'journal_mail' => $parse_bool($form_data['journal_mail'] ?? false),

                'temporary_work' => $form_data['temporary_work'] ?? '',
            ];

            // Handle employer: if manual entry, use Employer_free and set employer to null
            // Otherwise use employer lookup
            $is_manual = ($form_data['is_manual_employer'] === 'true' || $form_data['is_manual_employer'] === true);

            $this->log('Employer mapping - is_manual: ' . ($is_manual ? 'YES' : 'NO'));
            $this->log('Employer mapping - employer: ' . ($form_data['employer'] ?? 'EMPTY'));
            $this->log('Employer mapping - employer_id: ' . ($form_data['employer_id'] ?? 'EMPTY'));
            $this->log('Employer mapping - is_manual_employer value: ' . ($form_data['is_manual_employer'] ?? 'NOT SET'));

            if ($is_manual) {
                // Manual entry: write to Employer_free, set employer to null
                $crm_data['Employer_free'] = $form_data['employer'] ?? '';
                $crm_data['employer'] = null;
                $this->log('→ Using MANUAL employer, writing to Employer_free: "' . ($form_data['employer'] ?? '') . '"');
                $this->log('→ Setting employer lookup to NULL');
            } else {
                // Lookup entry: set employer ID, clear Employer_free
                if (!empty($form_data['employer_id'])) {
                    $crm_data['employer'] = $form_data['employer_id'];
                    $crm_data['Employer_free'] = '';
                    $this->log('→ Using LOOKUP employer, writing ID to employer: "' . $form_data['employer_id'] . '"');
                    $this->log('→ Clearing Employer_free');
                } else {
                    // No employer selected
                    $crm_data['employer'] = null;
                    $crm_data['Employer_free'] = '';
                    $this->log('→ NO employer selected, setting both to NULL/empty');
                }
            }

            return $crm_data;
        }

        /**
         * Sanitize form data
         */
        private function sanitize_form_data($post_data) {
            return [
                'ansprache' => sanitize_text_field($post_data['ansprache'] ?? ''),
                'akad_titel' => sanitize_text_field($post_data['akad_titel'] ?? ''),
                'titel_nach_name' => sanitize_text_field($post_data['titel_nach_name'] ?? ''),

                'mail1' => sanitize_email($post_data['mail1'] ?? ''),
                'mail2' => sanitize_email($post_data['mail2'] ?? ''),
                'mail3' => sanitize_email($post_data['mail3'] ?? ''),

                'strasse' => sanitize_text_field($post_data['strasse'] ?? ''),
                'adresszusatz' => sanitize_text_field($post_data['adresszusatz'] ?? ''),
                'plz' => sanitize_text_field($post_data['plz'] ?? ''),
                'ort' => sanitize_text_field($post_data['ort'] ?? ''),
                'land' => sanitize_text_field($post_data['land'] ?? 'Deutschland'),

                'telefon' => sanitize_text_field($post_data['telefon'] ?? ''),
                'mobil' => sanitize_text_field($post_data['mobil'] ?? ''),
                'diensttelefon' => sanitize_text_field($post_data['diensttelefon'] ?? ''),

                'journal_post' => sanitize_text_field($post_data['journal_post'] ?? 'false'),
                'journal_mail' => sanitize_text_field($post_data['journal_mail'] ?? 'false'),

                'employer' => sanitize_text_field($post_data['employer'] ?? ''),
                'employer_id' => sanitize_text_field($post_data['employer_id'] ?? ''),
                'is_manual_employer' => sanitize_text_field($post_data['is_manual_employer'] ?? ''),
                'temporary_work' => sanitize_text_field($post_data['temporary_work'] ?? ''),
            ];
        }

        /**
         * AJAX: Search accounts in Zoho CRM
         */
        public function ajax_load_accounts() {
            check_ajax_referer('dgptm_daten_bearbeiten_nonce', 'nonce');

            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => 'Nicht angemeldet']);
            }

            $search_term = sanitize_text_field($_POST['search'] ?? '');

            if (empty($search_term) || strlen($search_term) < 2) {
                wp_send_json_error(['message' => 'Bitte geben Sie mindestens 2 Zeichen ein']);
            }

            // Get OAuth token
            $token = $this->get_oauth_token();
            if (!$token) {
                wp_send_json_error(['message' => 'OAuth-Token nicht verfügbar']);
            }

            // Search accounts in Zoho CRM
            $accounts = $this->search_accounts($token, $search_term);

            if ($accounts === false) {
                wp_send_json_error(['message' => 'Fehler beim Suchen der Arbeitgeber']);
            }

            wp_send_json_success(['accounts' => $accounts]);
        }

        /**
         * AJAX: Load clinic accounts from Zoho CRM
         */
        public function ajax_load_clinics() {
            check_ajax_referer('dgptm_daten_bearbeiten_nonce', 'nonce');

            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => 'Nicht angemeldet']);
            }

            // Get OAuth token
            $token = $this->get_oauth_token();
            if (!$token) {
                wp_send_json_error(['message' => 'OAuth-Token nicht verfügbar']);
            }

            // Fetch clinic accounts from Zoho CRM
            $clinics = $this->fetch_all_accounts($token, 'Klinik');

            if ($clinics === false) {
                wp_send_json_error(['message' => 'Fehler beim Laden der Kliniken']);
            }

            wp_send_json_success(['clinics' => $clinics]);
        }

        /**
         * Search accounts in Zoho CRM by name
         */
        private function search_accounts($token, $search_term) {
            // Use Zoho Search API
            $url = 'https://www.zohoapis.eu/crm/v2/Accounts/search?criteria=(Account_Name:starts_with:' . urlencode($search_term) . ')&per_page=50';

            $response = wp_remote_get(
                $url,
                [
                    'headers' => [
                        'Authorization' => 'Zoho-oauthtoken ' . $token,
                    ],
                    'timeout' => 30
                ]
            );

            if (is_wp_error($response)) {
                $this->log('ERROR: Failed to search accounts: ' . $response->get_error_message());
                return false;
            }

            $http_code = wp_remote_retrieve_response_code($response);
            $body = json_decode(wp_remote_retrieve_body($response), true);

            if ($http_code === 204) {
                // No results found
                return [];
            }

            if ($http_code !== 200 || !isset($body['data'])) {
                $this->log('ERROR: Invalid response when searching accounts (HTTP ' . $http_code . ')');
                return false;
            }

            $accounts = [];
            foreach ($body['data'] as $account) {
                $accounts[] = [
                    'id' => $account['id'],
                    'name' => $account['Account_Name'] ?? 'Unbekannt',
                    'industry' => $account['Industry'] ?? '',
                ];
            }

            // Sort accounts alphabetically by name
            usort($accounts, function($a, $b) {
                return strcmp($a['name'], $b['name']);
            });

            $this->log('Found ' . count($accounts) . ' accounts matching "' . $search_term . '"');

            return $accounts;
        }

        /**
         * Fetch all accounts from Zoho CRM, optionally filtered by Industry
         */
        private function fetch_all_accounts($token, $industry_filter = null) {
            $all_accounts = [];
            $page = 1;
            $per_page = 200;

            do {
                $url = 'https://www.zohoapis.eu/crm/v2/Accounts?per_page=' . $per_page . '&page=' . $page;

                $response = wp_remote_get(
                    $url,
                    [
                        'headers' => [
                            'Authorization' => 'Zoho-oauthtoken ' . $token,
                        ],
                        'timeout' => 30
                    ]
                );

                if (is_wp_error($response)) {
                    $this->log('ERROR: Failed to fetch accounts: ' . $response->get_error_message());
                    return false;
                }

                $http_code = wp_remote_retrieve_response_code($response);
                $body = json_decode(wp_remote_retrieve_body($response), true);

                if ($http_code !== 200 || !isset($body['data'])) {
                    $this->log('ERROR: Invalid response when fetching accounts (HTTP ' . $http_code . ')');
                    return false;
                }

                foreach ($body['data'] as $account) {
                    // Filter by Industry if specified
                    if ($industry_filter && ($account['Industry'] ?? '') !== $industry_filter) {
                        continue;
                    }

                    $all_accounts[] = [
                        'id' => $account['id'],
                        'name' => $account['Account_Name'] ?? 'Unbekannt',
                        'industry' => $account['Industry'] ?? '',
                    ];
                }

                $has_more = isset($body['info']['more_records']) && $body['info']['more_records'];
                $page++;

            } while ($has_more);

            // Sort accounts alphabetically by name
            usort($all_accounts, function($a, $b) {
                return strcmp($a['name'], $b['name']);
            });

            $this->log('Fetched ' . count($all_accounts) . ' accounts' . ($industry_filter ? ' (Industry: ' . $industry_filter . ')' : ''));

            return $all_accounts;
        }

        /**
         * Extract employer name from employer field (can be lookup object or string)
         */
        private function extract_employer_name($employer_data) {
            if (empty($employer_data)) {
                $this->log('Employer data is empty');
                return '';
            }

            $this->log('Employer data type: ' . gettype($employer_data));
            $this->log('Employer data: ' . wp_json_encode($employer_data));

            // If it's an array/object with 'name' field (lookup)
            if (is_array($employer_data) && isset($employer_data['name'])) {
                $this->log('Extracted employer name: ' . $employer_data['name']);
                return $employer_data['name'];
            }

            // If it's a string
            if (is_string($employer_data)) {
                $this->log('Employer is string: ' . $employer_data);
                return $employer_data;
            }

            $this->log('Could not extract employer name');
            return '';
        }

        /**
         * Extract employer ID from employer field (can be lookup object or string)
         */
        private function extract_employer_id($employer_data) {
            if (empty($employer_data)) {
                return '';
            }

            $this->log('Extracting employer ID from: ' . wp_json_encode($employer_data));

            // If it's an array/object with 'id' field (lookup)
            if (is_array($employer_data) && isset($employer_data['id'])) {
                $this->log('Extracted employer ID: ' . $employer_data['id']);
                return $employer_data['id'];
            }

            return '';
        }

        /**
         * Log message
         */
        private function log($message) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[DGPTM Daten bearbeiten] ' . $message);
            }
        }
    }
}

// Prevent double initialization
if (!isset($GLOBALS['dgptm_daten_bearbeiten_initialized'])) {
    $GLOBALS['dgptm_daten_bearbeiten_initialized'] = true;
    DGPTM_Daten_Bearbeiten::get_instance();
}
