<?php
/**
 * Elementor Converter Class
 * Converts Elementor page data to Claude-friendly formats and back
 */

if (!defined('ABSPATH')) {
    exit;
}

class DGPTM_Elementor_Converter {

    /**
     * Export a page to Claude-friendly format
     */
    public function export_page($page_id, $format = 'markdown') {
        $post = get_post($page_id);

        if (!$post) {
            return new WP_Error('invalid_page', 'Seite nicht gefunden');
        }

        // Get Elementor data
        $elementor_data = get_post_meta($page_id, '_elementor_data', true);

        if (empty($elementor_data)) {
            return new WP_Error('no_elementor_data', 'Keine Elementor-Daten gefunden');
        }

        $data = json_decode($elementor_data, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error('json_error', 'Fehler beim Parsen der Elementor-Daten');
        }

        // Get page settings
        $page_settings = get_post_meta($page_id, '_elementor_page_settings', true);

        // Build export data
        $export_data = [
            'metadata' => [
                'page_id' => $page_id,
                'title' => $post->post_title,
                'post_type' => $post->post_type,
                'post_name' => $post->post_name,
                'exported_at' => current_time('Y-m-d H:i:s'),
                'elementor_version' => get_option('elementor_version'),
                'page_settings' => $page_settings ?: []
            ],
            'structure' => $this->parse_elementor_structure($data)
        ];

        // Generate output based on format
        switch ($format) {
            case 'markdown':
                return [
                    'format' => 'markdown',
                    'content' => $this->convert_to_markdown($export_data),
                    'filename' => sanitize_file_name($post->post_title) . '.md'
                ];

            case 'yaml':
                return [
                    'format' => 'yaml',
                    'content' => $this->convert_to_yaml($export_data),
                    'filename' => sanitize_file_name($post->post_title) . '.yaml'
                ];

            case 'json':
            default:
                return [
                    'format' => 'json',
                    'content' => json_encode($export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
                    'filename' => sanitize_file_name($post->post_title) . '.json'
                ];
        }
    }

    /**
     * Parse Elementor structure into readable format
     */
    private function parse_elementor_structure($data, $level = 0) {
        $structure = [];

        foreach ($data as $element) {
            $parsed = [
                'id' => $element['id'] ?? '',
                'type' => $element['elType'] ?? 'unknown',
                'level' => $level
            ];

            // Add widget-specific info
            if (isset($element['widgetType'])) {
                $parsed['widget'] = $element['widgetType'];
            }

            // Extract settings
            if (isset($element['settings']) && !empty($element['settings'])) {
                $parsed['settings'] = $this->extract_important_settings($element['settings'], $element['elType']);
            }

            // Parse children recursively
            if (isset($element['elements']) && !empty($element['elements'])) {
                $parsed['children'] = $this->parse_elementor_structure($element['elements'], $level + 1);
            }

            $structure[] = $parsed;
        }

        return $structure;
    }

    /**
     * Extract important settings (text, images, links, colors, etc.)
     */
    private function extract_important_settings($settings, $element_type) {
        $important = [];

        // Common important fields
        $important_fields = [
            // Content
            'text', 'title', 'description', 'content', 'editor', 'html',
            'heading', 'caption', 'button_text', 'link',

            // Media
            'image', 'background_image', 'video_link',

            // Styling (only if significant)
            'background_color', 'color', 'typography_font_family',

            // Layout
            'width', 'height', 'position',

            // Links and URLs
            'url', 'link', 'href'
        ];

        foreach ($settings as $key => $value) {
            // Skip empty values
            if (empty($value) && $value !== 0 && $value !== '0') {
                continue;
            }

            // Skip internal IDs
            if (strpos($key, '_id') !== false || strpos($key, 'element_id') !== false) {
                continue;
            }

            // Check if this is an important field
            $is_important = false;
            foreach ($important_fields as $field) {
                if (strpos($key, $field) !== false) {
                    $is_important = true;
                    break;
                }
            }

            if ($is_important) {
                // Handle complex objects (like images)
                if (is_array($value)) {
                    if (isset($value['url'])) {
                        $important[$key] = $value['url'];
                    } elseif (isset($value['id'])) {
                        $important[$key] = $value;
                    } else {
                        $important[$key] = $value;
                    }
                } else {
                    $important[$key] = $value;
                }
            }
        }

        return $important;
    }

    /**
     * Convert to Markdown format (most readable for Claude)
     */
    private function convert_to_markdown($data) {
        $output = "# Elementor Page Export: {$data['metadata']['title']}\n\n";

        // Metadata section
        $output .= "## Metadata\n\n";
        $output .= "```yaml\n";
        $output .= "page_id: {$data['metadata']['page_id']}\n";
        $output .= "title: \"{$data['metadata']['title']}\"\n";
        $output .= "post_type: {$data['metadata']['post_type']}\n";
        $output .= "post_name: {$data['metadata']['post_name']}\n";
        $output .= "exported_at: {$data['metadata']['exported_at']}\n";
        $output .= "elementor_version: {$data['metadata']['elementor_version']}\n";
        $output .= "```\n\n";

        // Page settings
        if (!empty($data['metadata']['page_settings'])) {
            $output .= "## Page Settings\n\n";
            $output .= "```json\n";
            $output .= json_encode($data['metadata']['page_settings'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            $output .= "\n```\n\n";
        }

        // Structure
        $output .= "## Page Structure\n\n";
        $output .= $this->structure_to_markdown($data['structure']);

        // Instructions for Claude
        $output .= "\n\n---\n\n";
        $output .= "## Anleitung für Bearbeitung\n\n";
        $output .= "Diese Datei zeigt die Struktur einer Elementor-Seite. Sie können:\n\n";
        $output .= "1. **Texte ändern**: Ändern Sie Werte in den `settings` Bereichen\n";
        $output .= "2. **Bilder ersetzen**: Ändern Sie `image` URLs\n";
        $output .= "3. **Links anpassen**: Ändern Sie `link` oder `url` Werte\n";
        $output .= "4. **Struktur verstehen**: Die Hierarchie zeigt Sections → Columns → Widgets\n\n";
        $output .= "**Wichtig**: Behalten Sie die Struktur (IDs, Types) bei, ändern Sie nur Inhalte!\n\n";
        $output .= "Nach der Bearbeitung können Sie die Datei zurück importieren.\n";

        return $output;
    }

    /**
     * Convert structure to readable Markdown
     */
    private function structure_to_markdown($structure, $depth = 0) {
        $output = '';
        $indent = str_repeat('  ', $depth);

        foreach ($structure as $element) {
            $type_label = $this->get_type_label($element['type'], $element['widget'] ?? null);

            $output .= "{$indent}- **{$type_label}** (ID: `{$element['id']}`)\n";

            // Show settings if any
            if (!empty($element['settings'])) {
                foreach ($element['settings'] as $key => $value) {
                    if (is_string($value)) {
                        $value_display = mb_strlen($value) > 100
                            ? mb_substr($value, 0, 100) . '...'
                            : $value;
                        $output .= "{$indent}  - `{$key}`: \"{$value_display}\"\n";
                    } elseif (is_array($value) && isset($value['url'])) {
                        $output .= "{$indent}  - `{$key}`: {$value['url']}\n";
                    } else {
                        $output .= "{$indent}  - `{$key}`: " . json_encode($value, JSON_UNESCAPED_UNICODE) . "\n";
                    }
                }
            }

            // Recursive for children
            if (!empty($element['children'])) {
                $output .= $this->structure_to_markdown($element['children'], $depth + 1);
            }

            $output .= "\n";
        }

        return $output;
    }

    /**
     * Get human-readable type label
     */
    private function get_type_label($type, $widget = null) {
        $labels = [
            'section' => 'Section',
            'column' => 'Column',
            'widget' => $widget ? "Widget: {$widget}" : 'Widget',
            'container' => 'Container'
        ];

        return $labels[$type] ?? ucfirst($type);
    }

    /**
     * Convert to YAML format
     */
    private function convert_to_yaml($data) {
        // Simple YAML converter (for basic compatibility)
        $output = "# Elementor Page Export\n\n";
        $output .= "metadata:\n";

        foreach ($data['metadata'] as $key => $value) {
            if (is_array($value)) {
                $output .= "  {$key}:\n";
                foreach ($value as $k => $v) {
                    $output .= "    {$k}: " . json_encode($v, JSON_UNESCAPED_UNICODE) . "\n";
                }
            } else {
                $output .= "  {$key}: " . json_encode($value, JSON_UNESCAPED_UNICODE) . "\n";
            }
        }

        $output .= "\nstructure:\n";
        $output .= $this->structure_to_yaml($data['structure'], 1);

        return $output;
    }

    /**
     * Convert structure to YAML
     */
    private function structure_to_yaml($structure, $level = 0) {
        $output = '';
        $indent = str_repeat('  ', $level);

        foreach ($structure as $i => $element) {
            $output .= "{$indent}- id: \"{$element['id']}\"\n";
            $output .= "{$indent}  type: {$element['type']}\n";

            if (isset($element['widget'])) {
                $output .= "{$indent}  widget: {$element['widget']}\n";
            }

            if (!empty($element['settings'])) {
                $output .= "{$indent}  settings:\n";
                foreach ($element['settings'] as $key => $value) {
                    if (is_array($value)) {
                        $output .= "{$indent}    {$key}: " . json_encode($value, JSON_UNESCAPED_UNICODE) . "\n";
                    } else {
                        $output .= "{$indent}    {$key}: " . json_encode($value, JSON_UNESCAPED_UNICODE) . "\n";
                    }
                }
            }

            if (!empty($element['children'])) {
                $output .= "{$indent}  children:\n";
                $output .= $this->structure_to_yaml($element['children'], $level + 2);
            }
        }

        return $output;
    }

    /**
     * Import modified content back to Elementor
     */
    public function import_page($page_id, $content) {
        // Create backup first
        $this->create_backup($page_id);

        // Try to parse the content
        $data = null;

        // Try JSON first
        $decoded = json_decode($content, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($decoded['structure'])) {
            $data = $decoded;
        } else {
            // Try to parse Markdown/YAML (simplified)
            return new WP_Error('format_error', 'Import unterstützt derzeit nur JSON-Format. Bitte exportieren Sie als JSON, bearbeiten Sie und importieren Sie zurück.');
        }

        // Rebuild Elementor data structure
        $elementor_data = $this->rebuild_elementor_data($data['structure']);

        // Update post meta
        update_post_meta($page_id, '_elementor_data', wp_slash(wp_json_encode($elementor_data)));

        // Clear Elementor cache
        if (class_exists('\Elementor\Plugin')) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }

        return true;
    }

    /**
     * Rebuild Elementor data from our structure
     */
    private function rebuild_elementor_data($structure) {
        $elements = [];

        foreach ($structure as $element) {
            $rebuilt = [
                'id' => $element['id'],
                'elType' => $element['type'],
                'settings' => $element['settings'] ?? []
            ];

            if (isset($element['widget'])) {
                $rebuilt['widgetType'] = $element['widget'];
            }

            if (isset($element['children'])) {
                $rebuilt['elements'] = $this->rebuild_elementor_data($element['children']);
            }

            $elements[] = $rebuilt;
        }

        return $elements;
    }

    /**
     * Create backup before import
     */
    private function create_backup($page_id) {
        $elementor_data = get_post_meta($page_id, '_elementor_data', true);
        $page_settings = get_post_meta($page_id, '_elementor_page_settings', true);

        $backup = [
            'elementor_data' => $elementor_data,
            'page_settings' => $page_settings,
            'timestamp' => current_time('mysql')
        ];

        // Store in transient (30 days)
        set_transient('elementor_ai_backup_' . $page_id, $backup, 30 * DAY_IN_SECONDS);

        return true;
    }
}
