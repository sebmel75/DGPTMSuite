# Changelog

## Version 1.3.0 (2025-11-29)

### 🐛 Bugfixes
- **Zertifikate/Punkte-Vergabe**: Behoben - Progress wird jetzt konsistent in `_vw_progress_{id}` und `_vw_watched_time_{id}` gespeichert
- **Wasserzeichen im Zertifikat**: Das ACF-Feld `certificate_watermark` wird jetzt korrekt in der PDF-Generierung verwendet
- **Completion-Trigger**: Serverseitige Validierung des tatsächlichen Fortschritts vor Punktevergabe

### ✨ Neue Features

#### Cookie-basierter Fortschritt für nicht-eingeloggte Benutzer
- Fortschritt wird per Cookie 30 Tage lang gespeichert
- Nach Login wird der Cookie-Fortschritt automatisch in die Datenbank übertragen
- Lokaler Fortschritt wird in der UI als "📱 Lokal" gekennzeichnet

#### Verlaufsanzeige
- "Zuletzt angesehen" Sektion in der Webinar-Liste für eingeloggte Benutzer
- Zeigt die letzten 5 angesehenen Webinare mit Fortschritt
- Relative Zeitangaben (Heute, Gestern, vor X Tagen)

#### Verbesserter Login-Hinweis
- Deutlicher Warnhinweis für nicht-eingeloggte Benutzer
- Information, dass Teilnahme nicht in Fortbildungsliste eingetragen wird
- Hinweis auf automatische Fortschritts-Übernahme nach Login

#### Zertifikat-Designer (Admin)
- Neuer visueller Editor für Zertifikat-Layout
- Live-Vorschau des Zertifikats
- PDF-Vorschau-Generierung
- Wasserzeichen-Einstellungen:
  - Bild-Upload
  - Position (5 Optionen: Mittig, Ecken)
  - Transparenz (10-100%)
- Pro-Webinar Wasserzeichen überschreibbar

#### Erfolgs-Modal
- Schönes Modal nach erfolgreichem Webinar-Abschluss
- Zeigt erhaltene EBCP-Punkte
- Direkter Download-Button für Zertifikat

### 🔧 Verbesserungen
- Fortschritts-Schwellwert-Anzeige im Fortschrittsbalken (rote Linie)
- Bessere visuelle Unterscheidung von lokalem vs. gespeichertem Fortschritt
- Responsive Design-Verbesserungen
- Performance-Optimierungen beim Tracking

### 📝 Technische Änderungen
- Neue AJAX-Handler: `vw_track_progress_nopriv`, `vw_transfer_cookie_progress`, `vw_preview_certificate`
- Neue Meta-Keys für konsistentes Progress-Tracking
- Verbesserte FPDF-Integration mit Fallback-Pfaden
- Neue Admin-Seite: Zertifikat Designer

## Version 1.2.4

- Siehe vorherige Changelog-Einträge
