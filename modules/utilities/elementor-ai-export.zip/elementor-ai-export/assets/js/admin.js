jQuery(document).ready(function($) {
    'use strict';

    const API = {
        getPages: function() {
            return $.ajax({
                url: elementorAiExport.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'elementor_ai_get_pages',
                    nonce: elementorAiExport.nonce
                }
            });
        },

        exportPage: function(pageId, format) {
            return $.ajax({
                url: elementorAiExport.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'elementor_ai_export_page',
                    nonce: elementorAiExport.nonce,
                    page_id: pageId,
                    format: format
                }
            });
        },

        importPage: function(pageId, content) {
            return $.ajax({
                url: elementorAiExport.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'elementor_ai_import_page',
                    nonce: elementorAiExport.nonce,
                    page_id: pageId,
                    content: content
                }
            });
        }
    };

    // Load pages
    function loadPages() {
        API.getPages().done(function(response) {
            if (response.success) {
                const pages = response.data.pages;

                const options = ['<option value="">-- Seite auswählen --</option>'];
                pages.forEach(function(page) {
                    options.push(
                        '<option value="' + page.id + '">' +
                        page.title + ' (' + page.type + ') - ' + page.modified +
                        '</option>'
                    );
                });

                $('#page-select, #import-page-select').html(options.join(''));
            } else {
                alert('Fehler beim Laden der Seiten: ' + (response.data.message || 'Unbekannter Fehler'));
            }
        }).fail(function() {
            alert('Netzwerkfehler beim Laden der Seiten');
        });
    }

    // Enable/disable export button
    $('#page-select').on('change', function() {
        $('#export-btn').prop('disabled', !$(this).val());
    });

    // Enable/disable import button
    $('#import-page-select, #import-content').on('change keyup', function() {
        const hasPage = $('#import-page-select').val();
        const hasContent = $('#import-content').val().trim();
        $('#import-btn').prop('disabled', !hasPage || !hasContent);
    });

    // Export page
    $('#export-btn').on('click', function() {
        const pageId = $('#page-select').val();
        const format = $('#format-select').val();

        if (!pageId) {
            alert('Bitte wählen Sie eine Seite aus');
            return;
        }

        const $btn = $(this);
        $btn.addClass('loading').prop('disabled', true);
        $('#export-result').hide();

        API.exportPage(pageId, format).done(function(response) {
            if (response.success) {
                const data = response.data;

                // Show result
                $('#export-content').val(data.content);
                $('#export-result').fadeIn();

                // Store for download
                $('#export-result').data('export', data);

                // Scroll to result
                $('html, body').animate({
                    scrollTop: $('#export-result').offset().top - 100
                }, 500);
            } else {
                alert('Fehler beim Export: ' + (response.data.message || 'Unbekannter Fehler'));
            }
        }).fail(function() {
            alert('Netzwerkfehler beim Export');
        }).always(function() {
            $btn.removeClass('loading').prop('disabled', false);
        });
    });

    // Copy to clipboard
    $('#copy-btn').on('click', function() {
        const $content = $('#export-content');
        $content.select();

        try {
            document.execCommand('copy');

            const $btn = $(this);
            const originalText = $btn.html();
            $btn.html('<span class="dashicons dashicons-yes"></span> Kopiert!');

            setTimeout(function() {
                $btn.html(originalText);
            }, 2000);
        } catch (err) {
            alert('Kopieren fehlgeschlagen. Bitte manuell kopieren.');
        }
    });

    // Download file
    $('#download-btn').on('click', function() {
        const exportData = $('#export-result').data('export');

        if (!exportData) {
            alert('Keine Export-Daten vorhanden');
            return;
        }

        const blob = new Blob([exportData.content], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = exportData.filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    });

    // Import page
    $('#import-btn').on('click', function() {
        const pageId = $('#import-page-select').val();
        const content = $('#import-content').val().trim();

        if (!pageId || !content) {
            alert('Bitte füllen Sie alle Felder aus');
            return;
        }

        // Validate JSON
        try {
            JSON.parse(content);
        } catch (e) {
            alert('Ungültiges JSON-Format. Bitte überprüfen Sie den Inhalt.');
            return;
        }

        // Confirm
        if (!confirm('Möchten Sie die Seite wirklich überschreiben? Ein Backup wird automatisch erstellt.')) {
            return;
        }

        const $btn = $(this);
        $btn.addClass('loading').prop('disabled', true);
        $('#import-result').hide();

        API.importPage(pageId, content).done(function(response) {
            const $result = $('#import-result');

            if (response.success) {
                $result.removeClass('error').addClass('success')
                    .html('<strong>Erfolg!</strong> Die Seite wurde erfolgreich aktualisiert. ' +
                          '<a href="' + getEditUrl(pageId) + '" target="_blank">In Elementor bearbeiten</a>')
                    .fadeIn();

                // Clear content
                $('#import-content').val('');
                $('#import-btn').prop('disabled', true);
            } else {
                $result.removeClass('success').addClass('error')
                    .html('<strong>Fehler!</strong> ' + (response.data.message || 'Unbekannter Fehler'))
                    .fadeIn();
            }
        }).fail(function() {
            $('#import-result').removeClass('success').addClass('error')
                .html('<strong>Netzwerkfehler!</strong> Der Import konnte nicht durchgeführt werden.')
                .fadeIn();
        }).always(function() {
            $btn.removeClass('loading').prop('disabled', false);
        });
    });

    // Helper: Get Elementor edit URL
    function getEditUrl(pageId) {
        return window.location.origin + '/wp-admin/post.php?post=' + pageId + '&action=elementor';
    }

    // Initialize
    loadPages();
});
