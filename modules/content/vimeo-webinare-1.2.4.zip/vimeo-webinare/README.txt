=== DGPTM - Vimeo Webinare ===
Contributors: sebastianmelzer
Tags: dgptm
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Vimeo Videos als Webinare mit dynamischen URLs (/wissen/webinar/{id}), automatischen Fortbildungspunkten, Zertifikaten und Frontend-Manager

== Description ==

Vimeo Videos als Webinare mit dynamischen URLs (/wissen/webinar/{id}), automatischen Fortbildungspunkten, Zertifikaten und Frontend-Manager

== Requirements ==

This plugin requires the following WordPress plugins to be installed and active:

* Advanced custom fields

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/vimeo-webinare` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Make sure all required plugins/modules are installed and active

== Changelog ==

= 1.2.4 =
* Initial release (exported from DGPTM Plugin Suite)
