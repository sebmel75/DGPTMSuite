jQuery(document).ready(function($) {
    'use strict';

    const $form = $('#dgptm-daten-form');
    const $loadingMessage = $('#loading-message');
    const $successMessage = $('#success-message');
    const $submitBtn = $('#submit-btn');
    const $formMessages = $('#form-messages');

    let clinicsData = [];
    let selectedEmployer = {
        name: '',
        id: ''
    };

    /**
     * Load member data on page load
     */
    function loadMemberData() {
        console.log('Loading member data...');
        console.log('AJAX URL:', dgptmDatenBearbeiten.ajaxUrl);
        console.log('Nonce:', dgptmDatenBearbeiten.nonce);

        $.ajax({
            url: dgptmDatenBearbeiten.ajaxUrl,
            type: 'POST',
            data: {
                action: 'dgptm_load_member_data',
                nonce: dgptmDatenBearbeiten.nonce
            },
            success: function(response) {
                console.log('Load response:', response);

                if (response.success && response.data) {
                    populateForm(response.data.data);
                    $loadingMessage.fadeOut(300, function() {
                        $form.fadeIn(300);
                    });
                } else {
                    var errorMsg = 'Fehler beim Laden der Daten';
                    if (response.data && response.data.message) {
                        errorMsg = response.data.message;
                    }
                    console.error('Error message:', errorMsg);
                    showErrorInPlace(errorMsg);
                    $loadingMessage.hide();
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Load error:', {
                    status: status,
                    error: error,
                    responseText: xhr.responseText
                });
                showErrorInPlace('Fehler beim Laden der Daten: ' + error);
                $loadingMessage.hide();
            }
        });
    }

    /**
     * Show error message in place of loading message
     */
    function showErrorInPlace(message) {
        $loadingMessage.html(
            '<div class="error-box">' +
            '<h3>Fehler</h3>' +
            '<p>' + message + '</p>' +
            '<p><small>Bitte kontaktieren Sie die Geschäftsstelle, wenn dieser Fehler weiterhin auftritt.</small></p>' +
            '</div>'
        );
    }

    /**
     * Search for accounts
     */
    function searchAccounts(searchTerm) {
        console.log('Searching accounts for:', searchTerm);

        if (!searchTerm || searchTerm.length < 2) {
            showError('Bitte geben Sie mindestens 2 Zeichen ein');
            return;
        }

        // Show loading indicator
        $('#employer_results').html('<div style="padding: 15px; text-align: center;">Suche läuft...</div>');
        $('#employer_results_row').show();

        $.ajax({
            url: dgptmDatenBearbeiten.ajaxUrl,
            type: 'POST',
            data: {
                action: 'dgptm_load_accounts',
                nonce: dgptmDatenBearbeiten.nonce,
                search: searchTerm
            },
            success: function(response) {
                console.log('Search results:', response);
                if (response.success && response.data.accounts) {
                    displaySearchResults(response.data.accounts);
                } else {
                    $('#employer_results').html('<div style="padding: 15px; text-align: center; color: #666;">Keine Ergebnisse gefunden</div>');
                }
            },
            error: function(xhr, status, error) {
                console.error('Search failed:', error);
                $('#employer_results').html('<div style="padding: 15px; text-align: center; color: #d63638;">Fehler bei der Suche</div>');
            }
        });
    }

    /**
     * Display search results
     */
    function displaySearchResults(accounts) {
        const $results = $('#employer_results');
        $results.empty();

        if (accounts.length === 0) {
            $results.html('<div style="padding: 15px; text-align: center; color: #666;">Keine Ergebnisse gefunden</div>');
            return;
        }

        accounts.forEach(function(account) {
            const $item = $('<div class="employer-result-item" data-id="' + account.id + '" data-name="' + account.name + '" style="padding: 12px; border-bottom: 1px solid #eee; cursor: pointer; transition: background 0.2s;">' +
                '<strong>' + account.name + '</strong>' +
                (account.industry ? '<br><small style="color: #666;">' + account.industry + '</small>' : '') +
                '</div>');

            $item.on('mouseenter', function() {
                $(this).css('background', '#f0f0f0');
            }).on('mouseleave', function() {
                $(this).css('background', 'white');
            }).on('click', function() {
                selectEmployer(account.id, account.name);
            });

            $results.append($item);
        });
    }

    /**
     * Select an employer
     */
    function selectEmployer(id, name) {
        selectedEmployer.id = id;
        selectedEmployer.name = name;

        // Update hidden fields
        $('#employer').val(name);
        $('#employer_id').val(id);

        // Update display
        $('#employer_current_name').text(name);

        // Hide search section
        $('#employer_search_section').hide();
        $('#employer_current_row').show();

        // Clear search
        $('#employer_search').val('');
        $('#employer_results_row').hide();

        // Check if service provider
        checkIfServiceProvider(name);

        console.log('Selected employer:', name, '(ID:', id + ')');
    }

    /**
     * Load clinics from Zoho CRM
     */
    function loadClinics() {
        console.log('Loading clinics...');

        $.ajax({
            url: dgptmDatenBearbeiten.ajaxUrl,
            type: 'POST',
            data: {
                action: 'dgptm_load_clinics',
                nonce: dgptmDatenBearbeiten.nonce
            },
            success: function(response) {
                console.log('Clinics loaded:', response);
                if (response.success && response.data.clinics) {
                    clinicsData = response.data.clinics;
                    populateClinicsDropdown();
                }
            },
            error: function(xhr, status, error) {
                console.error('Failed to load clinics:', error);
            }
        });
    }


    /**
     * Populate clinics dropdown
     */
    function populateClinicsDropdown() {
        const $temporaryWorkSelect = $('#temporary_work');
        $temporaryWorkSelect.empty();
        $temporaryWorkSelect.append('<option value="">Keine Ausleihe</option>');

        clinicsData.forEach(function(clinic) {
            $temporaryWorkSelect.append('<option value="' + clinic.name + '" data-id="' + clinic.id + '">' + clinic.name + '</option>');
        });
    }

    /**
     * Populate form with data
     */
    function populateForm(data) {
        console.log('Populating form with data:', data);

        // Text fields
        $('#ansprache').val(data.ansprache || 'Liebe(r)');
        $('#akad_titel').val(data.akad_titel || '');
        $('#titel_nach_name').val(data.titel_nach_name || '');

        // Read-only name field
        const fullName = (data.vorname || '') + ' ' + (data.nachname || '');
        $('#name').val(fullName.trim());

        // Email addresses
        $('#mail1').val(data.mail1 || '');
        $('#mail2').val(data.mail2 || '');
        $('#mail3').val(data.mail3 || '');

        // Address
        $('#strasse').val(data.strasse || '');
        $('#adresszusatz').val(data.adresszusatz || '');
        $('#plz').val(data.plz || '');
        $('#ort').val(data.ort || '');
        $('#land').val(data.land || 'Deutschland');

        // Phone numbers
        $('#telefon').val(data.telefon || '');
        $('#mobil').val(data.mobil || '');
        $('#diensttelefon').val(data.diensttelefon || '');

        // Employer - prioritize lookup, fallback to free text
        console.log('Employer data:', data.employer, 'ID:', data.employer_id, 'Free:', data.employer_free);

        let displayEmployer = '';

        if (data.employer) {
            // Lookup employer exists
            displayEmployer = data.employer;
            selectedEmployer.name = data.employer;
            selectedEmployer.id = data.employer_id || '';
            $('#employer').val(data.employer);
            $('#employer_id').val(data.employer_id || '');
        } else if (data.employer_free) {
            // Fallback to free text employer
            displayEmployer = data.employer_free;
            selectedEmployer.name = data.employer_free;
            selectedEmployer.id = '';
            $('#employer').val(data.employer_free);
            $('#employer_id').val('');
        }

        if (displayEmployer) {
            $('#employer_current_name').text(displayEmployer);
            console.log('Set employer display to:', displayEmployer);
            checkIfServiceProvider(displayEmployer);
        } else {
            console.log('No employer data, setting to "Nicht zugeordnet"');
            $('#employer_current_name').text('Nicht zugeordnet');
        }

        // Temporary work
        if (data.temporary_work) {
            $('#temporary_work').val(data.temporary_work);
        }

        // Journal preferences (checkboxes)
        $('#journal_post').prop('checked', data.journal_post === 'true' || data.journal_post === true);
        $('#journal_mail').prop('checked', data.journal_mail === 'true' || data.journal_mail === true);
    }

    /**
     * Check if employer is a service provider (WKK or LifeSystems)
     */
    function checkIfServiceProvider(employerName) {
        const serviceProviders = ['WKK', 'LifeSystems'];
        const isServiceProvider = serviceProviders.some(function(provider) {
            return employerName && employerName.includes(provider);
        });

        if (isServiceProvider) {
            $('#temporary_work_row').show();
        } else {
            $('#temporary_work_row').hide();
            $('#temporary_work').val('');
        }
    }

    /**
     * Handle "Change" button click
     */
    $('#employer_change_btn').on('click', function() {
        $('#employer_current_row').hide();
        $('#employer_search_section').show();
        $('#employer_search').focus();
    });

    /**
     * Handle search button click
     */
    $('#employer_search_btn').on('click', function() {
        const searchTerm = $('#employer_search').val().trim();
        searchAccounts(searchTerm);
    });

    /**
     * Handle Enter key in search field
     */
    $('#employer_search').on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            const searchTerm = $(this).val().trim();
            searchAccounts(searchTerm);
        }
    });

    /**
     * Handle "not in list" checkbox
     */
    $('#employer_not_in_list').on('change', function() {
        if ($(this).is(':checked')) {
            $('#employer_manual_row').show();
            $('#employer_results_row').hide();
        } else {
            $('#employer_manual_row').hide();
            $('#employer_manual').val('');
        }
    });

    /**
     * Handle form submission
     */
    $form.on('submit', function(e) {
        e.preventDefault();

        console.log('Form submitted');

        // Disable submit button
        $submitBtn.prop('disabled', true).text(dgptmDatenBearbeiten.strings.saving);
        $formMessages.empty();

        // Determine employer value and whether it's manual
        let employerValue = '';
        let employerId = '';
        let isManualEmployer = false;

        if ($('#employer_not_in_list').is(':checked')) {
            // Manual entry
            employerValue = $('#employer_manual').val();
            isManualEmployer = true;
        } else {
            // From selection or hidden field
            employerValue = $('#employer').val();
            employerId = $('#employer_id').val();
            isManualEmployer = false;
        }

        // Prepare form data
        const formData = {
            action: 'dgptm_update_member_data',
            nonce: dgptmDatenBearbeiten.nonce,

            ansprache: $('#ansprache').val(),
            akad_titel: $('#akad_titel').val(),
            titel_nach_name: $('#titel_nach_name').val(),

            mail1: $('#mail1').val(),
            mail2: $('#mail2').val(),
            mail3: $('#mail3').val(),

            strasse: $('#strasse').val(),
            adresszusatz: $('#adresszusatz').val(),
            plz: $('#plz').val(),
            ort: $('#ort').val(),
            land: $('#land').val(),

            telefon: $('#telefon').val(),
            mobil: $('#mobil').val(),
            diensttelefon: $('#diensttelefon').val(),

            employer: employerValue,
            employer_id: employerId,
            is_manual_employer: isManualEmployer ? 'true' : 'false',
            temporary_work: $('#temporary_work').val(),

            journal_post: $('#journal_post').is(':checked') ? 'true' : 'false',
            journal_mail: $('#journal_mail').is(':checked') ? 'true' : 'false'
        };

        console.log('Sending data:', formData);

        $.ajax({
            url: dgptmDatenBearbeiten.ajaxUrl,
            type: 'POST',
            data: formData,
            success: function(response) {
                console.log('Update response:', response);

                if (response.success) {
                    // Show success message
                    $form.fadeOut(300, function() {
                        $successMessage.fadeIn(300);
                    });

                    // Redirect after 2 seconds
                    setTimeout(function() {
                        window.location.href = dgptmDatenBearbeiten.redirectUrl;
                    }, 2000);
                } else {
                    showError(response.data.message || dgptmDatenBearbeiten.strings.error);
                    $submitBtn.prop('disabled', false).text('Daten ändern');
                }
            },
            error: function(xhr, status, error) {
                console.error('Update error:', error);
                showError(dgptmDatenBearbeiten.strings.error + ': ' + error);
                $submitBtn.prop('disabled', false).text('Daten ändern');
            }
        });
    });

    /**
     * Show error message
     */
    function showError(message) {
        $formMessages.html('<div class="error-message">' + message + '</div>').fadeIn();
    }

    // Load data on page load
    loadClinics();
    loadMemberData();
});
