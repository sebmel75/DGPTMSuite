<?php
/**
 * Plugin Name: DGPTM - Elementor AI Export
 * Description: Exportiert Elementor-Seiten in ein Claude-freundliches Format für einfache Bearbeitung und Re-Import
 * Version: 1.0.0
 * Author: Sebastian Melzer
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('DGPTM_Elementor_AI_Export')) {
    class DGPTM_Elementor_AI_Export {
        private static $instance = null;
        private $plugin_path;
        private $plugin_url;

        public static function get_instance() {
            if (null === self::$instance) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        private function __construct() {
            $this->plugin_path = plugin_dir_path(__FILE__);
            $this->plugin_url = plugin_dir_url(__FILE__);

            // Admin menu
            add_action('admin_menu', [$this, 'add_admin_menu']);

            // AJAX handlers
            add_action('wp_ajax_elementor_ai_export_page', [$this, 'ajax_export_page']);
            add_action('wp_ajax_elementor_ai_import_page', [$this, 'ajax_import_page']);
            add_action('wp_ajax_elementor_ai_get_pages', [$this, 'ajax_get_pages']);

            // Enqueue admin assets
            add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);

            // Load converter class
            require_once $this->plugin_path . 'includes/class-elementor-converter.php';
        }

        public function add_admin_menu() {
            add_submenu_page(
                'dgptm-suite',
                'Elementor AI Export',
                'AI Export',
                'manage_options',
                'elementor-ai-export',
                [$this, 'render_admin_page']
            );
        }

        public function enqueue_admin_assets($hook) {
            if ('dgptm-suite_page_elementor-ai-export' !== $hook) {
                return;
            }

            wp_enqueue_style(
                'elementor-ai-export-admin',
                $this->plugin_url . 'assets/css/admin.css',
                [],
                '1.0.0'
            );

            wp_enqueue_script(
                'elementor-ai-export-admin',
                $this->plugin_url . 'assets/js/admin.js',
                ['jquery'],
                '1.0.0',
                true
            );

            wp_localize_script('elementor-ai-export-admin', 'elementorAiExport', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('elementor_ai_export_nonce')
            ]);
        }

        public function render_admin_page() {
            require_once $this->plugin_path . 'views/admin-page.php';
        }

        public function ajax_get_pages() {
            check_ajax_referer('elementor_ai_export_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'Keine Berechtigung']);
            }

            $args = [
                'post_type' => ['page', 'post'],
                'posts_per_page' => -1,
                'meta_query' => [
                    [
                        'key' => '_elementor_edit_mode',
                        'value' => 'builder',
                        'compare' => '='
                    ]
                ],
                'orderby' => 'post_modified',
                'order' => 'DESC'
            ];

            $query = new WP_Query($args);
            $pages = [];

            foreach ($query->posts as $post) {
                $pages[] = [
                    'id' => $post->ID,
                    'title' => $post->post_title,
                    'type' => $post->post_type,
                    'modified' => get_the_modified_date('Y-m-d H:i:s', $post->ID),
                    'url' => get_permalink($post->ID)
                ];
            }

            wp_send_json_success(['pages' => $pages]);
        }

        public function ajax_export_page() {
            check_ajax_referer('elementor_ai_export_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'Keine Berechtigung']);
            }

            $page_id = intval($_POST['page_id']);
            $format = sanitize_text_field($_POST['format'] ?? 'markdown');

            if (!$page_id) {
                wp_send_json_error(['message' => 'Ungültige Seiten-ID']);
            }

            // Check if Elementor is active
            if (!did_action('elementor/loaded')) {
                wp_send_json_error(['message' => 'Elementor ist nicht aktiv']);
            }

            $converter = new DGPTM_Elementor_Converter();
            $result = $converter->export_page($page_id, $format);

            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()]);
            }

            wp_send_json_success($result);
        }

        public function ajax_import_page() {
            check_ajax_referer('elementor_ai_export_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'Keine Berechtigung']);
            }

            $page_id = intval($_POST['page_id']);
            $content = wp_unslash($_POST['content']);

            if (!$page_id || !$content) {
                wp_send_json_error(['message' => 'Ungültige Daten']);
            }

            // Check if Elementor is active
            if (!did_action('elementor/loaded')) {
                wp_send_json_error(['message' => 'Elementor ist nicht aktiv']);
            }

            $converter = new DGPTM_Elementor_Converter();
            $result = $converter->import_page($page_id, $content);

            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()]);
            }

            wp_send_json_success(['message' => 'Import erfolgreich']);
        }
    }
}

// Prevent double initialization
if (!isset($GLOBALS['dgptm_elementor_ai_export_initialized'])) {
    $GLOBALS['dgptm_elementor_ai_export_initialized'] = true;
    DGPTM_Elementor_AI_Export::get_instance();
}
