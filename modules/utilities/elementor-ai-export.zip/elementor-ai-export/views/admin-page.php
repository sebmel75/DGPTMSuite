<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap elementor-ai-export-wrap">
    <h1>Elementor AI Export</h1>

    <p class="description">
        Exportieren Sie Elementor-Seiten in ein Claude-freundliches Format. Claude kann dann die Inhalte verstehen und nach Ihren Wünschen anpassen.
    </p>

    <div class="elementor-ai-export-container">
        <!-- Export Section -->
        <div class="export-section card">
            <h2>Export</h2>

            <div class="export-controls">
                <div class="control-group">
                    <label for="page-select">Seite auswählen:</label>
                    <select id="page-select" class="regular-text">
                        <option value="">Laden...</option>
                    </select>
                </div>

                <div class="control-group">
                    <label for="format-select">Export-Format:</label>
                    <select id="format-select" class="regular-text">
                        <option value="markdown">Markdown (empfohlen für Claude)</option>
                        <option value="json">JSON (für Re-Import)</option>
                        <option value="yaml">YAML</option>
                    </select>
                </div>

                <button id="export-btn" class="button button-primary" disabled>
                    <span class="dashicons dashicons-download"></span>
                    Seite exportieren
                </button>
            </div>

            <div id="export-result" class="export-result" style="display:none;">
                <h3>Export erfolgreich</h3>
                <div class="export-preview">
                    <textarea id="export-content" readonly></textarea>
                </div>
                <div class="export-actions">
                    <button id="copy-btn" class="button">
                        <span class="dashicons dashicons-clipboard"></span>
                        In Zwischenablage kopieren
                    </button>
                    <button id="download-btn" class="button">
                        <span class="dashicons dashicons-download"></span>
                        Als Datei herunterladen
                    </button>
                </div>
            </div>
        </div>

        <!-- Import Section -->
        <div class="import-section card">
            <h2>Import</h2>

            <p class="description">
                Nachdem Claude Ihre Seite bearbeitet hat, können Sie die geänderte Version hier importieren.
                <strong>Wichtig:</strong> Nur JSON-Format wird beim Import unterstützt!
            </p>

            <div class="import-controls">
                <div class="control-group">
                    <label for="import-page-select">Ziel-Seite:</label>
                    <select id="import-page-select" class="regular-text">
                        <option value="">Laden...</option>
                    </select>
                </div>

                <div class="control-group">
                    <label for="import-content">Bearbeiteter Inhalt (JSON):</label>
                    <textarea id="import-content" rows="10" class="large-text code" placeholder="Fügen Sie hier den von Claude bearbeiteten JSON-Inhalt ein..."></textarea>
                </div>

                <div class="import-warning">
                    <span class="dashicons dashicons-warning"></span>
                    <strong>Achtung:</strong> Der Import überschreibt die aktuelle Seite. Ein automatisches Backup wird erstellt.
                </div>

                <button id="import-btn" class="button button-primary" disabled>
                    <span class="dashicons dashicons-upload"></span>
                    Änderungen importieren
                </button>
            </div>

            <div id="import-result" class="import-result" style="display:none;"></div>
        </div>

        <!-- Instructions -->
        <div class="instructions-section card">
            <h2>Anleitung</h2>

            <div class="instruction-steps">
                <div class="step">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h3>Seite exportieren</h3>
                        <p>Wählen Sie eine Elementor-Seite und exportieren Sie sie als Markdown (für beste Lesbarkeit) oder JSON (für Re-Import).</p>
                    </div>
                </div>

                <div class="step">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h3>Mit Claude bearbeiten</h3>
                        <p>Öffnen Sie <a href="https://claude.ai" target="_blank">claude.ai</a> und fügen Sie die exportierte Datei ein. Geben Sie Claude klare Anweisungen:</p>
                        <ul>
                            <li>"Ändere alle Überschriften zu..."</li>
                            <li>"Ersetze die Texte in Section X mit..."</li>
                            <li>"Passe die Farben an..."</li>
                        </ul>
                    </div>
                </div>

                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <h3>Zurück importieren</h3>
                        <p>Kopieren Sie Claudes Antwort (als JSON) und importieren Sie sie zurück in WordPress. Die Seite wird automatisch aktualisiert.</p>
                    </div>
                </div>
            </div>

            <div class="tips">
                <h3>Tipps für beste Ergebnisse</h3>
                <ul>
                    <li><strong>Markdown für Verständnis:</strong> Nutzen Sie Markdown-Export, damit Claude die Struktur gut versteht</li>
                    <li><strong>JSON für Import:</strong> Für den Re-Import brauchen Sie JSON-Format</li>
                    <li><strong>Klare Anweisungen:</strong> Sagen Sie Claude genau, welche Bereiche geändert werden sollen</li>
                    <li><strong>IDs beibehalten:</strong> Claude sollte die Element-IDs nicht ändern</li>
                    <li><strong>Backup vorhanden:</strong> Vor jedem Import wird automatisch ein Backup erstellt</li>
                </ul>
            </div>
        </div>
    </div>
</div>
